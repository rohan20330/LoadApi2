package com.demo.LoadApi.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demo.LoadApi.entities.Load;

public interface LoadDao extends JpaRepository<Load,Integer>{

}
